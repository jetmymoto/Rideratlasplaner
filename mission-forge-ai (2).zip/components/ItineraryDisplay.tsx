import React from 'react';
import { Itinerary, GroundingChunk, PointOfInterest } from '../types';
import { ClockIcon } from './icons/ClockIcon';
import { FocusIcon } from './icons/FocusIcon';
import { MapPinIcon } from './icons/MapPinIcon';
import { MotorcycleIcon } from './icons/MotorcycleIcon';
import { ShareIcon } from './icons/ShareIcon';
import { MapComponent } from './MapComponent';
import { generateAudioDossier, generateVideoFlythrough } from '../services/geminiService';
import { AudioWaveIcon } from './icons/AudioWaveIcon';
import { FinishFlagIcon } from './icons/FinishFlagIcon';
import { RouteIcon } from './icons/RouteIcon';
import { MountainIcon } from './icons/MountainIcon';
import { VideoIcon } from './icons/VideoIcon';
import { ShieldIcon } from './icons/ShieldIcon';
import { LeadCaptureModal } from './LeadCaptureModal';
import { submitLead } from '../services/dataService';

// --- Helper Functions for Audio Decoding ---
function decode(base64: string): Uint8Array {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const videoLoadingMessages = [
    "Scripting the shot list...",
    "Calibrating drone gimbal...",
    "Rendering scenic fly-through...",
    "Applying color grade...",
    "Finalizing aerial footage...",
    "This can take a few minutes..."
];


interface ItineraryDisplayProps {
  itinerary: Itinerary;
  groundingChunks: GroundingChunk[];
}

const InfoCard: React.FC<{ icon: React.ReactNode; title: string; value: string }> = ({ icon, title, value }) => (
    <div className="bg-gray-800 p-4 rounded-lg flex items-center space-x-4">
        <div className="text-orange-400">{icon}</div>
        <div>
            <p className="text-sm text-gray-400">{title}</p>
            <p className="font-bold text-white">{value}</p>
        </div>
    </div>
);

export const ItineraryDisplay: React.FC<ItineraryDisplayProps> = ({ itinerary, groundingChunks }) => {
  const [toastMessage, setToastMessage] = React.useState<string | null>(null);
  
  const [isAudioLoading, setIsAudioLoading] = React.useState(false);
  const [audioData, setAudioData] = React.useState<string | null>(null);
  const [audioError, setAudioError] = React.useState<string | null>(null);
  const [isPlaying, setIsPlaying] = React.useState(false);

  const [isVideoGenerating, setIsVideoGenerating] = React.useState(false);
  const [videoUrl, setVideoUrl] = React.useState<string | null>(null);
  const [videoError, setVideoError] = React.useState<string | null>(null);
  const [videoLoadingMessage, setVideoLoadingMessage] = React.useState(videoLoadingMessages[0]);

  type ImageState = { loading: boolean; data: string[] | null; error: string | null };
  const [poiImages, setPoiImages] = React.useState<{ [key: string]: ImageState }>({});
  const [poiImageIndex, setPoiImageIndex] = React.useState<{ [key: string]: number }>({});
  
  const [isModalOpen, setIsModalOpen] = React.useState(false);


  const audioContextRef = React.useRef<AudioContext | null>(null);
  const audioBufferRef = React.useRef<AudioBuffer | null>(null);
  const audioSourceRef = React.useRef<AudioBufferSourceNode | null>(null);
  const placesServiceRef = React.useRef<any | null>(null);

  React.useEffect(() => {
      // Initialize a single instance of the PlacesService
      if (window.google && window.google.maps && window.google.maps.places) {
          const map = new window.google.maps.Map(document.createElement('div'));
          placesServiceRef.current = new window.google.maps.places.PlacesService(map);
      }
  }, []);

  const handleShare = () => {
    try {
      const serializedItinerary = JSON.stringify(itinerary);
      const encodedData = btoa(serializedItinerary);
      const url = `${window.location.origin}${window.location.pathname}?itinerary=${encodedData}`;
      
      navigator.clipboard.writeText(url).then(() => {
        setToastMessage("Link copied to clipboard!");
        setTimeout(() => setToastMessage(null), 3000);
      }).catch(err => {
        console.error("Clipboard write failed:", err);
        setToastMessage("Failed to copy link.");
        setTimeout(() => setToastMessage(null), 3000);
      });

    } catch (error) {
      console.error("Failed to share itinerary:", error);
      setToastMessage("Failed to create share link.");
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleGenerateAudio = async () => {
    setIsAudioLoading(true);
    setAudioError(null);
    try {
      const result = await generateAudioDossier(itinerary);
      if (result) {
        setAudioData(result);
      } else {
        setAudioError("Received empty audio data.");
      }
    } catch (e: any) {
      setAudioError(e.message || "An unknown error occurred.");
    } finally {
      setIsAudioLoading(false);
    }
  };

  const stopAudio = () => {
     if (audioSourceRef.current) {
        audioSourceRef.current.onended = null; // Prevent onended from firing on manual stop
        audioSourceRef.current.stop();
        audioSourceRef.current = null;
        setIsPlaying(false);
      }
  };

  const handlePlayAudio = async () => {
    if (isPlaying) {
      stopAudio();
      return;
    }

    if (!audioData) return;

    if (!audioContextRef.current) {
       audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    const audioContext = audioContextRef.current;

    try {
        if (!audioBufferRef.current) {
            const decodedBytes = decode(audioData);
            audioBufferRef.current = await decodeAudioData(decodedBytes, audioContext, 24000, 1);
        }

        stopAudio();
        
        const source = audioContext.createBufferSource();
        source.buffer = audioBufferRef.current;
        source.connect(audioContext.destination);
        source.start();
        
        setIsPlaying(true);
        audioSourceRef.current = source;

        source.onended = () => {
            setIsPlaying(false);
            audioSourceRef.current = null;
        };
    } catch (error) {
        console.error("Failed to play audio:", error);
        setAudioError("Could not play the audio file.");
    }
  };
  
    const triggerGpxDownload = () => {
        const generateGpxContent = (itineraryData: Itinerary): string => {
            const escapeXml = (unsafe: string): string => {
                return unsafe.replace(/[<>&'"]/g, (c) => {
                    switch (c) {
                        case '<': return '&lt;';
                        case '>': return '&gt;';
                        case '&': return '&amp;';
                        case '\'': return '&apos;';
                        case '"': return '&quot;';
                        default: return c;
                    }
                });
            };

            let gpx = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="Mission Forge AI" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>${escapeXml(itineraryData.title)}</name>
    <desc>${escapeXml(itineraryData.description)}</desc>
  </metadata>
`;

            itineraryData.dailyPlan.forEach(day => {
                gpx += `  <rte>\n`;
                gpx += `    <name>${escapeXml(`Day ${day.day}: ${day.title}`)}</name>\n`;
                day.pois.forEach(poi => {
                    gpx += `    <rtept lat="${poi.latitude}" lon="${poi.longitude}">\n`;
                    gpx += `      <name>${escapeXml(poi.name)}</name>\n`;
                    gpx += `      <type>${escapeXml(poi.type)}</type>\n`;
                    gpx += `    </rtept>\n`;
                });
                gpx += `  </rte>\n`;
            });

            gpx += `</gpx>`;
            return gpx;
        };

        const gpxContent = generateGpxContent(itinerary);
        const filename = `${itinerary.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') || 'mission'}.gpx`;
        const blob = new Blob([gpxContent], { type: 'application/gpx+xml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleGpxButtonClick = () => {
        setIsModalOpen(true);
    };

    const handleModalSubmit = async (bikeModel: string) => {
        setIsModalOpen(false);
        // Step 6: "Ignite the 12 Zylinders" - Send data to the backend
        await submitLead(bikeModel, itinerary);
        // Step 5: "Value Delivery" - Download the GPX file
        triggerGpxDownload();
    };

  const handleVisualizePoi = async (poi: PointOfInterest, dayIndex: number, poiIndex: number) => {
      const key = `d${dayIndex}p${poiIndex}`;
      if (!placesServiceRef.current) {
          setPoiImages(prev => ({ ...prev, [key]: { loading: false, data: null, error: "Places API service is not available." } }));
          return;
      }

      setPoiImages(prev => ({ ...prev, [key]: { loading: true, data: null, error: null } }));

      const request = {
        query: `${poi.name}, ${itinerary.keyIntel.startLocation}`,
        fields: ['name', 'photos'],
      };

      placesServiceRef.current.textSearch(request, (results: any, status: any) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK && results && results[0]) {
            const place = results[0];
            if (place.photos && place.photos.length > 0) {
                const imageUrls = place.photos.slice(0, 5).map((photo: any) => photo.getUrl({ maxWidth: 400, maxHeight: 400 }));
                setPoiImages(prev => ({ ...prev, [key]: { loading: false, data: imageUrls, error: null } }));
                setPoiImageIndex(prev => ({ ...prev, [key]: 0 }));
            } else {
                setPoiImages(prev => ({ ...prev, [key]: { loading: false, data: null, error: "No photos found for this location." } }));
            }
        } else {
            setPoiImages(prev => ({ ...prev, [key]: { loading: false, data: null, error: "Could not find a matching photo." } }));
        }
      });
  };

  const handleSlideChange = (key: string, direction: 'next' | 'prev') => {
      const images = poiImages[key]?.data;
      if (!images) return;

      setPoiImageIndex(prev => {
          const currentIndex = prev[key] || 0;
          let nextIndex;
          if (direction === 'next') {
              nextIndex = (currentIndex + 1) % images.length;
          } else {
              nextIndex = (currentIndex - 1 + images.length) % images.length;
          }
          return { ...prev, [key]: nextIndex };
      });
  };

  const handleGenerateVideo = async () => {
    setIsVideoGenerating(true);
    setVideoError(null);
    setVideoUrl(null);
    
    const interval = setInterval(() => {
        setVideoLoadingMessage(prev => {
            const currentIndex = videoLoadingMessages.indexOf(prev);
            return videoLoadingMessages[(currentIndex + 1) % videoLoadingMessages.length];
        });
    }, 3000);

    try {
        const downloadUri = await generateVideoFlythrough(itinerary);
        if (downloadUri) {
            // Fetch the video data as a blob
            const response = await fetch(downloadUri);
            if (!response.ok) {
                throw new Error(`Failed to fetch video: ${response.status} ${response.statusText}`);
            }
            const videoBlob = await response.blob();
            // Create a local URL for the blob to use in the video player
            const objectUrl = URL.createObjectURL(videoBlob);
            setVideoUrl(objectUrl);
        } else {
            setVideoError("Received empty video data from the service.");
        }
    } catch (e: any) {
        setVideoError(e.message || "An unknown error occurred during video generation.");
    } finally {
        clearInterval(interval);
        setIsVideoGenerating(false);
    }
  };

  React.useEffect(() => {
    // This effect handles cleanup for the created object URL to prevent memory leaks.
    const currentVideoUrl = videoUrl;
    return () => {
        if (currentVideoUrl && currentVideoUrl.startsWith('blob:')) {
            URL.revokeObjectURL(currentVideoUrl);
        }
    };
  }, [videoUrl]);


  React.useEffect(() => {
    // This effect handles cleanup for audio resources on component unmount.
    return () => {
        stopAudio();
        audioContextRef.current?.close();
    };
  }, []);

  const renderAudioDossier = () => {
      if (audioError) {
          return (
              <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  <div>
                    <h4 className="font-bold text-white">Audio Dossier Error</h4>
                    <p className="text-sm text-red-400">{audioError}</p>
                  </div>
              </div>
          );
      }
      
      if (audioData) {
          return (
             <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
                <AudioWaveIcon className="h-10 w-10 text-gray-400" />
                <div>
                  <h4 className="font-bold text-white">Audio Dossier Ready</h4>
                   <button onClick={handlePlayAudio} className="text-sm text-orange-400 hover:text-orange-300 font-semibold focus:outline-none">
                       {isPlaying ? 'Stop Dossier' : 'Play Dossier'}
                   </button>
                </div>
            </div>
          );
      }

      if (isAudioLoading) {
           return (
             <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
                <div className="w-10 h-10 border-2 border-dashed rounded-full animate-spin border-orange-500"></div>
                <div>
                  <h4 className="font-bold text-white">Generating Audio Dossier</h4>
                  <p className="text-sm text-gray-400 animate-pulse">Please wait...</p>
                </div>
            </div>
          );
      }

      return (
         <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
            <AudioWaveIcon className="h-10 w-10 text-gray-500" />
            <div>
              <h4 className="font-bold text-white">Audio Dossier</h4>
               <button onClick={handleGenerateAudio} className="text-sm text-orange-400 hover:text-orange-300 font-semibold focus:outline-none">
                   Generate Audio Summary
               </button>
            </div>
        </div>
      );
  };

  const renderVideoFlythrough = () => {
    if (videoError) {
        return (
            <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <div>
                  <h4 className="font-bold text-white">Video Fly-through Error</h4>
                  <p className="text-sm text-red-400">{videoError}</p>
                </div>
            </div>
        );
    }
    
    if (videoUrl) {
        return (
           <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">Virtual Drone Fly-through</h4>
              <video controls src={videoUrl} className="w-full rounded-md" />
          </div>
        );
    }

    if (isVideoGenerating) {
         return (
           <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
              <div className="w-10 h-10 border-2 border-dashed rounded-full animate-spin border-orange-500"></div>
              <div>
                <h4 className="font-bold text-white">Generating Fly-through</h4>
                <p className="text-sm text-gray-400 animate-pulse">{videoLoadingMessage}</p>
              </div>
          </div>
        );
    }

    return (
       <div className="bg-gray-800 rounded-lg p-4 flex items-center space-x-4">
          <VideoIcon className="h-10 w-10 text-gray-500" />
          <div>
            <h4 className="font-bold text-white">Virtual Drone Fly-through</h4>
             <button onClick={handleGenerateVideo} className="text-sm text-orange-400 hover:text-orange-300 font-semibold focus:outline-none">
                 Generate Cinematic Preview
             </button>
          </div>
      </div>
    );
  };


  return (
    <>
    <div className="animate-fade-in w-full max-w-5xl mx-auto p-4 text-gray-200 space-y-8">
      <div className="text-center p-6 border-b-2 border-orange-500/30">
        <h2 className="text-4xl font-extrabold text-white tracking-tight">{itinerary.title}</h2>
        <p className="text-orange-400 text-lg mt-2 italic">{itinerary.tagline}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h3 className="text-2xl font-bold mb-3 text-white">Mission Briefing</h3>
            <p className="text-gray-300 leading-relaxed mb-6">{itinerary.description}</p>
            <MapComponent dailyPlans={itinerary.dailyPlan} />
          </div>
        </div>

        <div className="space-y-4">
            <h3 className="text-2xl font-bold text-white">Key Intel</h3>
            <InfoCard icon={<ClockIcon className="w-8 h-8"/>} title="Duration" value={itinerary.keyIntel.duration} />
            <InfoCard icon={<MapPinIcon className="w-8 h-8"/>} title="Launch Point" value={itinerary.keyIntel.startLocation} />
            <InfoCard icon={<FinishFlagIcon className="w-8 h-8"/>} title="End Point" value={itinerary.keyIntel.endLocation} />
            <InfoCard icon={<RouteIcon className="w-8 h-8"/>} title="Total Distance" value={itinerary.keyIntel.totalDistance} />
            <InfoCard icon={<MotorcycleIcon className="w-8 h-8"/>} title="Recommended Machine" value={itinerary.keyIntel.bikeType} />
            <InfoCard icon={<FocusIcon className="w-8 h-8"/>} title="Mission Focus" value={itinerary.keyIntel.focus} />
            <InfoCard icon={<MountainIcon className="w-8 h-8"/>} title="Terrain Focus" value={itinerary.keyIntel.terrainFocus} />
            
            {itinerary.keyIntel.emergencyContacts && itinerary.keyIntel.emergencyContacts.length > 0 && (
              <div className="pt-2">
                  <h4 className="text-xl font-bold text-white mb-2">Mission Support</h4>
                  {itinerary.keyIntel.emergencyContacts.map(contact => (
                      <InfoCard key={contact.country} icon={<ShieldIcon className="w-8 h-8"/>} title={`${contact.country} Emergency`} value={contact.number} />
                  ))}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <button 
                    onClick={handleGpxButtonClick}
                    className="w-full px-6 py-3 bg-green-600 text-white font-bold rounded-md hover:bg-green-500 transition-transform duration-200 transform hover:scale-105"
                >
                    Download GPX
                </button>
                <button 
                    onClick={handleShare}
                    className="w-full flex items-center justify-center px-6 py-3 bg-purple-600 text-white font-bold rounded-md hover:bg-purple-500 transition-transform duration-200 transform hover:scale-105"
                >
                    <ShareIcon className="w-5 h-5 mr-2" />
                    Share Mission
                </button>
            </div>
            
           <div className="grid grid-cols-1 gap-4 pt-4">
            {renderVideoFlythrough()}
            {renderAudioDossier()}
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-3xl font-bold mb-4 text-center text-white">Daily Operations</h3>
        <div className="space-y-6">
          {itinerary.dailyPlan.map((day, dayIndex) => (
            <div key={day.day} className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
              <div className="flex items-baseline space-x-4 mb-3">
                <span className="text-orange-400 font-extrabold text-2xl">Day {day.day}</span>
                <h4 className="text-xl font-bold text-white">{day.title}</h4>
              </div>
              <p className="text-gray-400 italic mb-4">{day.routeSummary}</p>
              <p className="text-gray-300 mb-4">{day.description}</p>
              <div>
                <h5 className="font-semibold text-gray-100 mb-3">Points of Interest:</h5>
                <ul className="space-y-4">
                    {day.pois.map((poi, poiIndex) => {
                        const key = `d${dayIndex}p${poiIndex}`;
                        const imageState = poiImages[key];
                        const currentIndex = poiImageIndex[key] || 0;
                        return (
                            <li key={poiIndex} className="bg-gray-900/50 p-4 rounded-md flex flex-col md:flex-row md:items-start gap-4">
                                <div className="flex-grow">
                                    <p className="font-semibold text-white">{poi.name}</p>
                                    <p className="text-sm text-gray-400">{poi.type}</p>
                                </div>
                                <div className="md:w-64 h-40 flex-shrink-0 bg-gray-800 rounded-md flex items-center justify-center relative">
                                    {imageState?.data && (
                                        <div className="relative w-full h-full">
                                            <img src={imageState.data[currentIndex]} alt={`Visualization of ${poi.name}`} className="w-full h-full object-cover rounded-md"/>
                                            {imageState.data.length > 1 && (
                                                <>
                                                    <button onClick={() => handleSlideChange(key, 'prev')} className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-1 rounded-full hover:bg-black/80 focus:outline-none transition-opacity opacity-70 hover:opacity-100">
                                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                                    </button>
                                                    <button onClick={() => handleSlideChange(key, 'next')} className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white p-1 rounded-full hover:bg-black/80 focus:outline-none transition-opacity opacity-70 hover:opacity-100">
                                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                                    </button>
                                                    <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
                                                        {currentIndex + 1} / {imageState.data.length}
                                                    </div>
                                                </>
                                            )}
                                        </div>
                                    )}
                                    {imageState?.loading && <div className="w-12 h-12 border-4 border-dashed rounded-full animate-spin border-orange-500"></div>}
                                    {imageState?.error && <p className="text-red-400 text-xs text-center p-2">{imageState.error}</p>}
                                    {!imageState && (
                                        <button onClick={() => handleVisualizePoi(poi, dayIndex, poiIndex)} className="px-4 py-2 bg-blue-600 text-white font-semibold text-sm rounded-md hover:bg-blue-500 transition-colors">
                                            Visualize
                                        </button>
                                    )}
                                </div>
                            </li>
                        )
                    })}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>

       {groundingChunks.length > 0 && (
          <div className="pt-6 border-t border-gray-700">
              <h3 className="text-lg font-semibold mb-2 text-gray-300">Intelligence Sources (via Google Maps):</h3>
              <ul className="list-disc list-inside text-sm text-blue-400 space-y-1">
                  {groundingChunks.filter(chunk => chunk.maps).map((chunk, index) => (
                      <li key={index}>
                          <a href={chunk.maps.uri} target="_blank" rel="noopener noreferrer" className="hover:underline">
                              {chunk.maps.title}
                          </a>
                      </li>
                  ))}
              </ul>
          </div>
      )}
      
      {toastMessage && (
        <div className="fixed bottom-10 left-1/2 bg-gray-700 border border-gray-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in-up z-20">
          {toastMessage}
        </div>
      )}
    </div>
    {isModalOpen && <LeadCaptureModal onSubmit={handleModalSubmit} onClose={() => setIsModalOpen(false)} />}
    </>
  );
};
