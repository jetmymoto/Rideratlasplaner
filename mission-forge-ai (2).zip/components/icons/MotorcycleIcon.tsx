import React from 'react';

export const MotorcycleIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 16.5c0 1.932-1.568 3.5-3.5 3.5s-3.5-1.568-3.5-3.5 1.568-3.5 3.5-3.5 3.5 1.568 3.5 3.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.5 16.5c0 1.932-1.568 3.5-3.5 3.5S1.5 18.432 1.5 16.5 3.068 13 5 13s3.5 1.568 3.5 3.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.5 13H9.5l-1.5-5h7l-1.5 5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 8l1-4H8.5l1 4h4z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.5 5.5a1 1 0 100-2 1 1 0 000 2z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.5 8l-2 5" />
  </svg>
);