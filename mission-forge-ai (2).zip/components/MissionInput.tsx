
import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';

interface MissionInputProps {
  onSubmit: (prompt: string) => void;
  isLoading: boolean;
}

export const MissionInput: React.FC<MissionInputProps> = ({ onSubmit, isLoading }) => {
  const [prompt, setPrompt] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim() && !isLoading) {
      onSubmit(prompt);
    }
  };

  const placeholderText = "I have 3 days free next month. I want to fly into Lyon, France. Show me a mission with incredible food and maximum twisties. I'll be on my BMW R1300GS.";

  return (
    <div className="w-full max-w-3xl mx-auto p-4">
      <form onSubmit={handleSubmit}>
        <label htmlFor="mission-prompt" className="block text-2xl font-semibold text-center text-gray-200 mb-4">
          Commander, what is your next mission?
        </label>
        <div className="relative">
          <textarea
            id="mission-prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={placeholderText}
            className="w-full h-32 p-4 pr-12 text-lg text-gray-100 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-300 resize-none"
            disabled={isLoading}
          />
        </div>
        <div className="mt-4 flex justify-center">
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="flex items-center justify-center px-8 py-3 bg-orange-600 text-white font-bold text-lg rounded-md hover:bg-orange-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-transform duration-200 transform hover:scale-105"
          >
            <SparklesIcon className="w-6 h-6 mr-2" />
            {isLoading ? 'Forging...' : 'Forge Mission'}
          </button>
        </div>
      </form>
    </div>
  );
};
