import React from 'react';

interface LeadCaptureModalProps {
  onSubmit: (bikeModel: string) => void;
  onClose: () => void;
}

export const LeadCaptureModal: React.FC<LeadCaptureModalProps> = ({ onSubmit, onClose }) => {
  const [bikeModel, setBikeModel] = React.useState('');
  const modalRef = React.useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bikeModel.trim()) {
      onSubmit(bikeModel.trim());
    }
  };

  // Close modal if clicking outside of it
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-fade-in">
      <div ref={modalRef} className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-lg w-full mx-4 border-2 border-orange-500/50">
        <h2 className="text-3xl font-bold text-center text-white mb-4">Awesome! What are you riding?</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={bikeModel}
            onChange={(e) => setBikeModel(e.target.value)}
            placeholder="e.g., Ducati Panigale, BMW R1250GS"
            className="w-full p-3 text-lg text-gray-100 bg-gray-700 border-2 border-gray-600 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-300"
            autoFocus
          />
          <button
            type="submit"
            disabled={!bikeModel.trim()}
            className="w-full mt-6 px-8 py-3 bg-orange-600 text-white font-bold text-lg rounded-md hover:bg-orange-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-transform duration-200 transform hover:scale-105"
          >
            Download My Route
          </button>
        </form>
      </div>
    </div>
  );
};
