
import React from 'react';

const messages = [
  "Analyzing Commander's Request...",
  "Gathering Market Intelligence...",
  "Calculating Twistiness Factor...",
  "Plotting Thrilling Routes...",
  "Engaging Creative Layering Protocol...",
  "Assembling Masterpiece Itinerary...",
];

export const LoadingSpinner: React.FC = () => {
  const [message, setMessage] = React.useState(messages[0]);

  React.useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % messages.length;
      setMessage(messages[index]);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center space-y-4 text-white p-8">
      <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-orange-500"></div>
      <p className="text-lg font-semibold animate-pulse">{message}</p>
    </div>
  );
};
