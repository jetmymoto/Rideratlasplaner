import React, { useEffect, useRef, useState } from 'react';
import { DayPlan } from '../types';

// Fix: Add a global declaration for 'google' to resolve TypeScript errors
// by augmenting the Window interface for the Google Maps JavaScript API.
declare global {
  interface Window {
    google: any;
  }
}

interface MapComponentProps {
  dailyPlans: DayPlan[];
}

const mapStyles = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

const routeColors = ['#F44336', '#2196F3', '#4CAF50', '#FFC107', '#9C27B0', '#FF5722', '#795548'];

export const MapComponent: React.FC<MapComponentProps> = ({ dailyPlans }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any | null>(null);
  const infoWindow = useRef<any | null>(null);
  const directionsRenderers = useRef<any[]>([]);
  const [isApiLoaded, setIsApiLoaded] = useState(!!(window.google && window.google.maps));

  useEffect(() => {
    // This effect checks for the Google Maps API script, which is loaded asynchronously.
    const checkApi = () => {
      if (window.google && window.google.maps) {
        setIsApiLoaded(true);
        return true;
      }
      return false;
    };
    
    if (checkApi()) return;

    // Poll for the API to load every 500ms.
    const intervalId = setInterval(() => {
      if (checkApi()) {
        clearInterval(intervalId);
      }
    }, 500);

    // Stop polling after 5 seconds to prevent an infinite loop if the API fails to load.
    const timeoutId = setTimeout(() => {
      clearInterval(intervalId);
      if (!isApiLoaded) {
          setIsApiLoaded(prev => prev ? prev : false);
      }
    }, 5000);

    return () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
    };
  }, [isApiLoaded]);


  useEffect(() => {
    if (!isApiLoaded || !mapRef.current || !window.google) return;

    const initialCenter = dailyPlans[0]?.pois[0] 
        ? { lat: dailyPlans[0].pois[0].latitude, lng: dailyPlans[0].pois[0].longitude }
        : { lat: 45.8, lng: 6.8 }; // Default fallback

    if (!mapInstance.current) {
        mapInstance.current = new window.google.maps.Map(mapRef.current, {
          center: initialCenter,
          zoom: 8,
          styles: mapStyles,
          disableDefaultUI: true,
          zoomControl: true,
          scaleControl: true,
        });
        infoWindow.current = new window.google.maps.InfoWindow();
    }

    // Clear previous routes before drawing new ones
    directionsRenderers.current.forEach(renderer => renderer.setMap(null));
    directionsRenderers.current = [];

    const directionsService = new window.google.maps.DirectionsService();
    const bounds = new window.google.maps.LatLngBounds();

    dailyPlans.forEach((day, dayIndex) => {
        // Create custom markers for all POIs
        day.pois.forEach((poi, poiIndex) => {
            const markerPosition = { lat: poi.latitude, lng: poi.longitude };
            const marker = new window.google.maps.Marker({
            position: markerPosition,
            map: mapInstance.current,
            title: poi.name,
            icon: {
                path: window.google.maps.SymbolPath.CIRCLE,
                scale: 5,
                fillColor: routeColors[dayIndex % routeColors.length],
                fillOpacity: 1,
                strokeWeight: 1,
                strokeColor: '#FFFFFF',
            },
            label: {
                text: `${day.day}.${poiIndex + 1}`,
                color: 'white',
                fontSize: '10px',
                fontWeight: 'bold',
            }
            });

            marker.addListener('click', () => {
                infoWindow.current?.setContent(`
                    <div style="color: #000; padding: 5px;">
                    <h4 style="margin: 0 0 5px 0; font-weight: bold;">${poi.name}</h4>
                    <p style="margin: 0;">${poi.type}</p>
                    </div>
                `);
                infoWindow.current?.open(mapInstance.current, marker);
            });
            bounds.extend(markerPosition);
        });
    });

    if (mapInstance.current && !bounds.isEmpty()) {
        mapInstance.current.fitBounds(bounds);
    }
    
    // Process route directions sequentially to avoid API rate limits (e.g., OVER_QUERY_LIMIT)
    const processDayRoutes = async () => {
      for (const [dayIndex, day] of dailyPlans.entries()) {
        if (day.pois.length < 2) continue;

        const origin = day.pois[0];
        const destination = day.pois[day.pois.length - 1];
        const waypoints = day.pois.slice(1, -1).map(poi => ({
            location: { lat: poi.latitude, lng: poi.longitude },
            stopover: true,
        }));

        const request = {
            origin: { lat: origin.latitude, lng: origin.longitude },
            destination: { lat: destination.latitude, lng: destination.longitude },
            waypoints: waypoints,
            travelMode: window.google.maps.TravelMode.DRIVING,
            avoidHighways: true,
        };

        // Wrap the callback-based API in a Promise to allow for sequential execution
        await new Promise<void>(resolve => {
          directionsService.route(request, (result: any, status: any) => {
              if (status === window.google.maps.DirectionsStatus.OK) {
                  const directionsRenderer = new window.google.maps.DirectionsRenderer({
                      map: mapInstance.current,
                      directions: result,
                      suppressMarkers: true, // We use our custom markers
                      polylineOptions: {
                          strokeColor: routeColors[dayIndex % routeColors.length],
                          strokeOpacity: 0.8,
                          strokeWeight: 4,
                      },
                  });
                  directionsRenderers.current.push(directionsRenderer);
              } else {
                  console.error(`Directions request failed due to ${status} for Day ${day.day}`);
              }
              // Add a small delay before resolving to stagger requests and avoid rate limits
              setTimeout(() => resolve(), 200);
          });
        });
      }
    };

    processDayRoutes();

  }, [dailyPlans, isApiLoaded]);

  if (!isApiLoaded) {
    return (
      <div style={{ height: '500px', width: '100%', borderRadius: '8px', backgroundColor: '#242f3e' }} className="flex flex-col items-center justify-center text-center p-4 border border-orange-500/50">
        <h3 className="text-xl font-bold text-orange-400">Map Unavailable</h3>
        <p className="text-gray-300 mt-2 max-w-md">
          The Google Maps API did not load. This is usually due to an incorrect or missing API key.
        </p>
        <p className="text-gray-400 mt-2 text-sm">
          Please check the console for errors and ensure the API key in <code className="bg-gray-900 p-1 rounded text-xs font-mono">index.html</code> is correct.
        </p>
      </div>
    );
  }

  return <div ref={mapRef} style={{ height: '500px', width: '100%', borderRadius: '8px', backgroundColor: '#242f3e' }} />;
};