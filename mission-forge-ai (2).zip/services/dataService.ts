import { Itinerary } from '../types';
import { APP_ID, database } from './firebaseConfig';
import { ref, push } from 'firebase/database';

/**
 * Submits the captured lead data directly to Firebase Realtime Database.
 * This function is the "Ignite the 12 Zylinders" step of the Hurricane Funnel.
 * 
 * IMPORTANT: For this to work, you MUST configure your Realtime Database
 * Security Rules to allow public write access to the '/artifacts/{APP_ID}/crm_leads' path.
 * 
 * @param bikeModel The motorcycle model entered by the user.
 * @param itinerary The full itinerary object the user generated.
 */
export const submitLead = async (bikeModel: string, itinerary: Itinerary): Promise<void> => {
  const leadsRef = ref(database, `artifacts/${APP_ID}/crm_leads`);

  // This payload is structured according to the crm_leads data model
  // specified in the "Project Iron Legion" architecture document.
  const payload = {
    source_platform: "Mission Forge AI",
    source_group: null,
    profile_url: null,
    name: null,
    status: "IDENTIFIED",
    bike: bikeModel,
    archetype: null, // To be determined by a backend agent
    agent_last_contact: null,
    // The "conversation_summary" holds the rich "Intent" data (the generated route).
    conversation_summary: itinerary,
    linked_userid: null,
    capturedAt: new Date().toISOString(), // Adding a timestamp for when the lead was captured
  };

  try {
    // Push the new lead data to the Realtime Database, which generates a unique key.
    await push(leadsRef, payload);
    console.log('Lead successfully submitted to Hurricane CMR (Realtime Database).');
  } catch (error) {
    console.error('Error writing to Realtime Database:', error);
    // In a production environment, you might want to log this to a monitoring service.
    // For the user's sake, we proceed with the GPX download even if this fails. The promise is kept.
  }
};