import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { Itinerary, LocationCoords, GroundingChunk } from '../types';

// Fix: Escaped backticks in the template literal to prevent TypeScript from interpreting them as template placeholders and causing 'Cannot find name' errors.
const getForgeMissionPrompt = (userPrompt: string) => {
  return `
    You are "Mission Forge AI," a next-generation conversational AI for the exclusive Hangar Club. Your purpose is to generate bespoke, premium motorcycle itineraries based on a user's natural language request.

    When you receive a user's request, follow this multi-stage process:

    1.  **Deconstruction (Analyze):** Parse the user's prompt to identify key entities:
        *   \\\`duration\\\` (in days)
        *   \\\`startLocation\\\` (city, country)
        *   \\\`destination\\\` (city, country, if specified)
        *   \\\`interests\\\` (e.g., "culinary", "twisties", "scenic", "history")
        *   \\\`motorcycle\\\` (e.g., "BMW R1300GS")

    2.  **Route Type Decision:** Based on your analysis, determine the itinerary type.
        *   If a \\\`destination\\\` is clearly specified, you MUST create a **Point-to-Point** itinerary.
        *   If no \\\`destination\\\` is specified, you MUST create a **Loop** itinerary that starts and ends at the \\\`startLocation\\\`.

    3.  **Intelligence Gathering (Scout):** Use your Google Maps tool for reconnaissance with these strict rules:
        *   **For a Loop Itinerary:** Perform a hyper-focused search within a 200km radius of the \\\`startLocation\\\`.
        *   **For a Point-to-Point Itinerary:** Plan a logical, continuous, and fully rideable motorcycle route from the \\\`startLocation\\\` to the \\\`destination\\\`.
        *   You MUST include a maximum of one 'Restaurant' or 'Culinary' type Point of Interest per day.
        *   For "twisties" or "scenic" interests, find roads with significant elevation changes and turns.
        *   For each POI, you MUST include its precise \\\`latitude\\\` and \\\`longitude\\\`.

    4.  **Route Assembly & Realism (Synthesize):**
        *   **Ferry Avoidance (CRITICAL RULE):** The primary planned route MUST be entirely on land. Do not include ferry crossings as part of the main \\\`pois\\\` list for routing.
        *   **Daily Distance Management (CRITICAL RULE):** The maximum daily riding distance should generally not exceed 600km to ensure an enjoyable and safe pace. If a direct land route between overnight stops is significantly longer than this, your primary solution is to **add another day to the itinerary**. Break the long segment into two or more reasonably distanced riding days, adding a new overnight accommodation stop.
        *   **Route Continuity (CRITICAL RULE):** The end point of Day 'N' (i.e., the last POI in the \\\`pois\\\` array for that day) MUST be the same geographical location as the start point of Day 'N+1' (the first POI in the \\\`pois\\\` array for the next day).
        *   **Accommodation Mandate (CRITICAL RULE):** The final Point of Interest for each day's plan MUST be a suitable 'Accommodation' (e.g., Hotel, Guesthouse, B&B) for the overnight stay. This POI will also serve as the starting point for the next day.
        *   Calculate the \\\`totalDistance\\\` for the entire mission and include it in the Key Intel.

    5.  **Creative & Safety Layering (Enrich):**
        *   Generate a unique and exciting \\\`title\\\` and \\\`tagline\\\` for the mission.
        *   Write a compelling \\\`description\\\` for the overall mission.
        *   Summarize the \\\`keyIntel\\\`, including a \\\`terrainFocus\\\`.
        *   **Emergency Contacts:** Identify every country the route passes through. For each country, provide the standard emergency contact number for vehicle breakdown or general assistance (e.g., for Germany, the number for ADAC is +49 89 22 22 22). Add this to the \\\`emergencyContacts\\\` field.
        *   **Optional Ferry Note:** If a ferry is a very common and time-saving alternative for an excessively long land route, you may mention it as an *optional suggestion* within the \\\`description\\\` for that day's plan. The planned route itself must remain on land. For example: "This is a substantial riding day covering over 550km. As an alternative to shorten the time, you could consider the ferry from [Port A] to [Port B]. However, our planned mission route follows the spectacular coastal roads..."

    6.  **Final Output:** Your final response MUST be a single JSON object formatted within a markdown code block (\\\`\\\`\\\`json ... \\\`\\\`\\\`). Do not include any other text outside this block. The JSON object must conform to this exact structure:
        {
          "title": "string",
          "tagline": "string",
          "description": "string",
          "keyIntel": {
            "duration": "string (e.g., '3 Days')",
            "startLocation": "string",
            "endLocation": "string",
            "totalDistance": "string (e.g., 'Approx. 1200km')",
            "bikeType": "string",
            "focus": "string (e.g., 'Culinary & Twisties')",
            "terrainFocus": "string (e.g., 'Mountain Passes & Coastal Roads')",
            "emergencyContacts": [
                { "country": "string", "number": "string" }
            ]
          },
          "dailyPlan": [
            {
              "day": "number",
              "title": "string",
              "description": "A vivid, engaging narrative of the day's ride. Describe the road types (e.g., 'serpentine mountain passes', 'sun-drenched coastal highways'), the scenery ('riding through ancient olive groves', 'overlooking the turquoise sea'), and the overall atmosphere of the day's journey. Make the rider feel excited to be there.",
              "routeSummary": "string (e.g., 'Approx. 250km / 5 hours riding')",
              "pois": [
                {
                  "name": "string",
                  "type": "string (e.g., 'Restaurant', 'Viewpoint', 'Accommodation')",
                  "latitude": "number",
                  "longitude": "number"
                }
              ]
            }
          ]
        }
    
    User's Mission Request: "${userPrompt}"
    `;
};

const parseJsonResponse = (text: string): Itinerary | null => {
  const match = text.match(/```json\n([\s\S]*?)\n```/);
  if (match && match[1]) {
    try {
      return JSON.parse(match[1]) as Itinerary;
    } catch (e) {
      console.error("Failed to parse JSON from model response:", e);
      return null;
    }
  }
  return null;
};


export const forgeMission = async (prompt: string, location: LocationCoords | null): Promise<{ itinerary: Itinerary | null, groundingChunks: GroundingChunk[] }> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set. Please select a key.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const toolConfig = location ? {
      retrievalConfig: {
        latLng: {
          latitude: location.latitude,
          longitude: location.longitude,
        }
      }
    } : undefined;

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: getForgeMissionPrompt(prompt),
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: toolConfig,
    },
  });

  const itinerary = parseJsonResponse(response.text);
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] || [];
  
  return { itinerary, groundingChunks };
};

export const generateAudioDossier = async (itinerary: Itinerary): Promise<string | null> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set. Please select a key.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Construct a detailed script for the TTS model.
  const script = `
    Mission Briefing for: ${itinerary.title}.
    Tagline: ${itinerary.tagline}.
    Overview: ${itinerary.description}.
    The mission is divided into ${itinerary.dailyPlan.length} operational days.
    ${itinerary.dailyPlan.map(day => `
      Day ${day.day}: ${day.title}.
      Route Summary: ${day.routeSummary}.
      Briefing: ${day.description}.
    `).join('')}
    End of mission briefing.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: script }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Puck' }, // A crisp, professional voice for a dossier.
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return base64Audio;
    }
    return null;
  } catch (error) {
    console.error("Audio dossier generation failed:", error);
    throw new Error("Failed to generate audio dossier from the AI service.");
  }
};

export const generateVideoFlythrough = async (itinerary: Itinerary): Promise<string | null> => {
  if (!process.env.API_KEY) {
      throw new Error("API_KEY environment variable not set. Please select a key.");
  }
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const poiHighlights = itinerary.dailyPlan.flatMap(day => day.pois.map(poi => poi.name)).slice(0, 5).join(', ');
  const videoPrompt = `
    Create a cinematic, high-energy trailer for a motorcycle journey titled "${itinerary.title}".
    Showcase thrilling drone shots of a ${itinerary.keyIntel.bikeType} riding through scenic landscapes like ${itinerary.keyIntel.terrainFocus}.
    Include quick cuts of key locations such as ${poiHighlights}.
    The overall mood should be adventurous, premium, and exciting.
    Focus on dynamic aerial views, sweeping roads, and beautiful scenery.
  `;

  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: videoPrompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    // Poll for the result
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (downloadLink) {
        // The API key must be appended to the download link for authentication
        return `${downloadLink}&key=${process.env.API_KEY}`;
    }
    return null;
  } catch (error) {
    console.error("Video fly-through generation failed:", error);
    throw new Error("Failed to generate video fly-through from the AI service.");
  }
};