import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// IMPORTANT: Replace these placeholder values with your actual Firebase project configuration.
// This configuration is used to connect your web app to your Firebase project.
// You can find this object in your Firebase project settings under "General".

export const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "your-project-id.firebaseapp.com",
  databaseURL: "https://your-project-id-default-rtdb.firebaseio.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:1234567890abcdef123456",
  measurementId: "G-XXXXXXXXXX"
};

// This is your multi-tenant App ID, as specified in the "Iron Legion" architecture.
// It should match the {appId} used in your Firestore paths (e.g., /artifacts/{appId}/...).
export const APP_ID = "mission-forge-ai-v1";

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Realtime Database and get a reference to the service
export const database = getDatabase(app);
