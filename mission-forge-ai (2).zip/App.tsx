import React from 'react';
import { Header } from './components/Header';
import { MissionInput } from './components/MissionInput';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ItineraryDisplay } from './components/ItineraryDisplay';
import { forgeMission } from './services/geminiService';
import type { Itinerary, LocationCoords, GroundingChunk } from './types';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [itinerary, setItinerary] = React.useState<Itinerary | null>(null);
  const [groundingChunks, setGroundingChunks] = React.useState<GroundingChunk[]>([]);
  const [location, setLocation] = React.useState<LocationCoords | null>(null);

  React.useEffect(() => {
    // --- Geolocation ---
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (geoError) => {
        console.warn("Geolocation denied. Proceeding without user location.", geoError);
        setLocation(null);
      }
    );

    // --- Shared Itinerary Check ---
    const params = new URLSearchParams(window.location.search);
    const itineraryData = params.get('itinerary');

    if (itineraryData) {
        try {
            const decodedData = atob(itineraryData);
            const parsedItinerary: Itinerary = JSON.parse(decodedData);
            setItinerary(parsedItinerary);
            // Grounding chunks are not part of the shared link for simplicity.
            setGroundingChunks([]);
        } catch (error) {
            console.error("Failed to parse shared itinerary from URL:", error);
            setError("The shared mission link appears to be invalid.");
        } finally {
            // Clean the URL to prevent re-processing or accidental re-sharing
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    }
  }, []);

  const handleForgeMission = async (prompt: string) => {
    setIsLoading(true);
    setError(null);
    setItinerary(null);
    setGroundingChunks([]);

    try {
      const result = await forgeMission(prompt, location);
      if (result.itinerary) {
        setItinerary(result.itinerary);
        setGroundingChunks(result.groundingChunks);
      } else {
        setError("The Huracan Engine couldn't forge a mission from your request. Please try a different prompt.");
      }
    } catch (e: unknown) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Mission Forge failed. Reason: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans antialiased">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center space-y-8">
            {!itinerary && <MissionInput onSubmit={handleForgeMission} isLoading={isLoading} />}
            
            {isLoading && <LoadingSpinner />}
            
            {error && (
                <div className="my-4 p-4 bg-red-900/50 border border-red-500 text-red-300 rounded-lg text-center max-w-2xl">
                    <h3 className="font-bold">Error</h3>
                    <p>{error}</p>
                </div>
            )}
            
            {itinerary && !isLoading && (
              <>
                <ItineraryDisplay itinerary={itinerary} groundingChunks={groundingChunks} />
                <button 
                  onClick={() => {
                    setItinerary(null);
                  }}
                  className="mt-8 px-8 py-3 bg-blue-600 text-white font-bold text-lg rounded-md hover:bg-blue-500 transition-transform duration-200 transform hover:scale-105"
                >
                  Forge Another Mission
                </button>
              </>
            )}
        </div>
      </main>
    </div>
  );
};

export default App;
