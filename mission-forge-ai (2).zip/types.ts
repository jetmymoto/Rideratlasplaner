export interface PointOfInterest {
  name: string;
  type: string;
  latitude: number;
  longitude: number;
}

export interface DayPlan {
  day: number;
  title: string;
  description: string;
  routeSummary: string;
  pois: PointOfInterest[];
}

export interface EmergencyContact {
  country: string;
  number: string;
}

export interface KeyIntel {
  duration: string;
  startLocation: string;
  endLocation: string;
  totalDistance: string;
  bikeType: string;
  focus: string;
  terrainFocus: string;
  emergencyContacts: EmergencyContact[];
}

export interface Itinerary {
  title: string;
  tagline: string;
  description: string;
  keyIntel: KeyIntel;
  dailyPlan: DayPlan[];
}

export interface GroundingChunk {
  maps: {
    title: string;
    uri: string;
  };
}

export interface LocationCoords {
  latitude: number;
  longitude: number;
}
